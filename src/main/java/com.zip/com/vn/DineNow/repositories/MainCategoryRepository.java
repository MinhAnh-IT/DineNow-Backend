package com.vn.DineNow.repositories;

import com.vn.DineNow.entities.MainCategory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MainCategoryRepository extends JpaRepository<MainCategory, Long> {
}
