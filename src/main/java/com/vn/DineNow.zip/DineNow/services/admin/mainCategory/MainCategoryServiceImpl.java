package com.vn.DineNow.services.admin.mainCategory;

public class MainCategoryServiceImpl implements MainCategoryService {
}
