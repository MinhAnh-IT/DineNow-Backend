package com.vn.DineNow.services.admin.mainCategory;

public interface MainCategoryService {
}
