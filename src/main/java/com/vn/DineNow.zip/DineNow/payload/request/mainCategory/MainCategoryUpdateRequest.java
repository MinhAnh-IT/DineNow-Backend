package com.vn.DineNow.payload.request.mainCategory;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MainCategoryUpdateRequest {
    String name;
    String description;
}
