package com.vn.DineNow.payload.response.OrderItem;

public class OrderItemResponse {
    Long menuItemId;
    Integer quantity;
    Long price;
    String name;
    String imageUrl;
}
