package com.vn.DineNow.repositories;

import com.vn.DineNow.entities.MenuItemReview;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MenuItemReviewRepository extends JpaRepository<MenuItemReview, Long> {
}
