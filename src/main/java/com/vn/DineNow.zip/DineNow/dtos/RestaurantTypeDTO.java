package com.vn.DineNow.dtos;

import lombok.Data;

@Data
public class RestaurantTypeDTO {
    private Long id;
    private String name;
    private String description;
}
